export let collectionId = "";

export const setUniqueValue = (u) => {
    collectionId = u;
};
